const { DynamoDBClient, UpdateItemCommand } = require('@aws-sdk/client-dynamodb');
const client = new DynamoDBClient({ region: "ap-south-1" });

exports.handler = async (event) => {
  
  try {
    // Get the partition key from the URL path parameters
    const partitionKeyValue = event.pathParameters.id;
    
    // Get the new remarks value from the request body
    const { remarks } = JSON.parse(event.body);
    
    // Basic validation
    if (!partitionKeyValue) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing ID in the URL path" })
      };
    }
    
    if (remarks === undefined) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing remarks in request body" })
      };
    }
    
    // Create update command specifically for the remarks field
    const command = new UpdateItemCommand({
      TableName: process.env.TABLE_NAME,
      Key: {
        "id": { S: partitionKeyValue }
      },
      UpdateExpression: "SET remarks = :remarks",
      ExpressionAttributeValues: {
        ":remarks": { S: remarks }
      },
      ReturnValues: "ALL_NEW"
    });
    
    // Execute the update
    const response = await client.send(command);
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Remarks updated successfully",
        item: response.Attributes
      })
    };
    
  } catch (error) {
    console.error("Error updating remarks:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to update remarks" })
    };
  }
};